/*==============================================================*/
/* DBMS name:      Microsoft SQL Server 2017                    */
/* Created on:     1/12/2024 13:35:37                           */
/*==============================================================*/


if exists (select 1
   from sys.sysreferences r join sys.sysobjects o on (o.id = r.constid and o.type = 'F')
   where r.fkeyid = object_id('ASESORES') and o.name = 'FK_ASESORES_CONSECION_CONSECIO')
alter table ASESORES
   drop constraint FK_ASESORES_CONSECION_CONSECIO
go

if exists (select 1
   from sys.sysreferences r join sys.sysobjects o on (o.id = r.constid and o.type = 'F')
   where r.fkeyid = object_id('CARROS') and o.name = 'FK_CARROS_CONSECION_CONSECIO')
alter table CARROS
   drop constraint FK_CARROS_CONSECION_CONSECIO
go

if exists (select 1
   from sys.sysreferences r join sys.sysobjects o on (o.id = r.constid and o.type = 'F')
   where r.fkeyid = object_id('CLIENTES') and o.name = 'FK_CLIENTES_CONSECION_CONSECIO')
alter table CLIENTES
   drop constraint FK_CLIENTES_CONSECION_CONSECIO
go

if exists (select 1
   from sys.sysreferences r join sys.sysobjects o on (o.id = r.constid and o.type = 'F')
   where r.fkeyid = object_id('COTIZACIONES') and o.name = 'FK_COTIZACI_COTIZACIO_ASESORES')
alter table COTIZACIONES
   drop constraint FK_COTIZACI_COTIZACIO_ASESORES
go

if exists (select 1
   from sys.sysreferences r join sys.sysobjects o on (o.id = r.constid and o.type = 'F')
   where r.fkeyid = object_id('COTIZACIONES') and o.name = 'FK_COTIZACI_COTIZACIO_CARROS')
alter table COTIZACIONES
   drop constraint FK_COTIZACI_COTIZACIO_CARROS
go

if exists (select 1
   from sys.sysreferences r join sys.sysobjects o on (o.id = r.constid and o.type = 'F')
   where r.fkeyid = object_id('COTIZACIONES') and o.name = 'FK_COTIZACI_COTIZACIO_CLIENTES')
alter table COTIZACIONES
   drop constraint FK_COTIZACI_COTIZACIO_CLIENTES
go

if exists (select 1
            from  sysindexes
           where  id    = object_id('ASESORES')
            and   name  = 'CONSECIONARIA_ASESORES_FK'
            and   indid > 0
            and   indid < 255)
   drop index ASESORES.CONSECIONARIA_ASESORES_FK
go

if exists (select 1
            from  sysobjects
           where  id = object_id('ASESORES')
            and   type = 'U')
   drop table ASESORES
go

if exists (select 1
            from  sysindexes
           where  id    = object_id('CARROS')
            and   name  = 'CONSECIONARIA_CARROS_FK'
            and   indid > 0
            and   indid < 255)
   drop index CARROS.CONSECIONARIA_CARROS_FK
go

if exists (select 1
            from  sysobjects
           where  id = object_id('CARROS')
            and   type = 'U')
   drop table CARROS
go

if exists (select 1
            from  sysindexes
           where  id    = object_id('CLIENTES')
            and   name  = 'CONSECIONARIA_CLIENTES_FK'
            and   indid > 0
            and   indid < 255)
   drop index CLIENTES.CONSECIONARIA_CLIENTES_FK
go

if exists (select 1
            from  sysobjects
           where  id = object_id('CLIENTES')
            and   type = 'U')
   drop table CLIENTES
go

if exists (select 1
            from  sysobjects
           where  id = object_id('CONSECIONARIA')
            and   type = 'U')
   drop table CONSECIONARIA
go

if exists (select 1
            from  sysindexes
           where  id    = object_id('COTIZACIONES')
            and   name  = 'COTIZACION_CLIENTES_FK'
            and   indid > 0
            and   indid < 255)
   drop index COTIZACIONES.COTIZACION_CLIENTES_FK
go

if exists (select 1
            from  sysindexes
           where  id    = object_id('COTIZACIONES')
            and   name  = 'COTIZACION_CARRO_FK'
            and   indid > 0
            and   indid < 255)
   drop index COTIZACIONES.COTIZACION_CARRO_FK
go

if exists (select 1
            from  sysindexes
           where  id    = object_id('COTIZACIONES')
            and   name  = 'COTIZACION_ASESORES_FK'
            and   indid > 0
            and   indid < 255)
   drop index COTIZACIONES.COTIZACION_ASESORES_FK
go

if exists (select 1
            from  sysobjects
           where  id = object_id('COTIZACIONES')
            and   type = 'U')
   drop table COTIZACIONES
go

/*==============================================================*/
/* Table: ASESORES                                              */
/*==============================================================*/
create table ASESORES (
   ID_ASESOR            int                  not null,
   ID_CONSECIONARIA     int                  null,
   CEDULA_ASESOR        varchar(10)          not null,
   NOMBRES              varchar(128)         not null,
   APELLIDOS            varchar(128)         not null,
   EMAIL                varchar(128)         not null,
   SUELDO               float                not null,
   TOKEN_CREDENCIAL     varchar(1024)        not null,
   PORCENTAJE_COMISION  float                not null,
   constraint PK_ASESORES primary key (ID_ASESOR)
)
go

/*==============================================================*/
/* Index: CONSECIONARIA_ASESORES_FK                             */
/*==============================================================*/




create nonclustered index CONSECIONARIA_ASESORES_FK on ASESORES (ID_CONSECIONARIA ASC)
go

/*==============================================================*/
/* Table: CARROS                                                */
/*==============================================================*/
create table CARROS (
   CHASIS               varchar(17)          not null,
   ID_CONSECIONARIA     int                  null,
   NOMBRE_MODELO        varchar(1024)        not null,
   TIPO_TRANSMISION     smallint             not null,
   COLOR                varchar(1024)        not null,
   TIPO_COMBUSTIBLE     varchar(1024)        not null,
   CONSUMO              varchar(1024)        not null,
   PRECIO_STANDARD      float                not null,
   YEAR                 numeric              not null,
   constraint PK_CARROS primary key (CHASIS)
)
go

/*==============================================================*/
/* Index: CONSECIONARIA_CARROS_FK                               */
/*==============================================================*/




create nonclustered index CONSECIONARIA_CARROS_FK on CARROS (ID_CONSECIONARIA ASC)
go

/*==============================================================*/
/* Table: CLIENTES                                              */
/*==============================================================*/
create table CLIENTES (
   CEDULA               int                  not null,
   ID_CONSECIONARIA     int                  null,
   NOMBRES              varchar(128)         not null,
   APELLIDOS            varchar(128)         not null,
   FECHA_NACIMIENTO     datetime             not null,
   TELEFONO             varchar(16)          not null,
   CIUDAD_RESIDENCIA    varchar(128)         not null,
   EMAIL                varchar(128)         not null,
   constraint PK_CLIENTES primary key (CEDULA)
)
go

/*==============================================================*/
/* Index: CONSECIONARIA_CLIENTES_FK                             */
/*==============================================================*/




create nonclustered index CONSECIONARIA_CLIENTES_FK on CLIENTES (ID_CONSECIONARIA ASC)
go

/*==============================================================*/
/* Table: CONSECIONARIA                                         */
/*==============================================================*/
create table CONSECIONARIA (
   ID_CONSECIONARIA     int                  not null,
   DIRECCION            varchar(128)         not null,
   HORARIO_TALLERES     varchar(128)         not null,
   HORARIO_SHOWROOM     varchar(128)         not null,
   _CONTACTO_VENTAS     varchar(16)          not null,
   CONTACTO_PBX         varchar(16)          not null,
   CONTACTO_POSTVENTA   varchar(16)          not null,
   constraint PK_CONSECIONARIA primary key (ID_CONSECIONARIA)
)
go

/*==============================================================*/
/* Table: COTIZACIONES                                          */
/*==============================================================*/
create table COTIZACIONES (
   ID_COTIZACION        int                  not null,
   ID_ASESOR            int                  null,
   CHASIS               varchar(17)          null,
   CEDULA               int                  null,
   FECHA                datetime             not null,
   constraint PK_COTIZACIONES primary key (ID_COTIZACION)
)
go

/*==============================================================*/
/* Index: COTIZACION_ASESORES_FK                                */
/*==============================================================*/




create nonclustered index COTIZACION_ASESORES_FK on COTIZACIONES (ID_ASESOR ASC)
go

/*==============================================================*/
/* Index: COTIZACION_CARRO_FK                                   */
/*==============================================================*/




create nonclustered index COTIZACION_CARRO_FK on COTIZACIONES (CHASIS ASC)
go

/*==============================================================*/
/* Index: COTIZACION_CLIENTES_FK                                */
/*==============================================================*/




create nonclustered index COTIZACION_CLIENTES_FK on COTIZACIONES (CEDULA ASC)
go

alter table ASESORES
   add constraint FK_ASESORES_CONSECION_CONSECIO foreign key (ID_CONSECIONARIA)
      references CONSECIONARIA (ID_CONSECIONARIA)
go

alter table CARROS
   add constraint FK_CARROS_CONSECION_CONSECIO foreign key (ID_CONSECIONARIA)
      references CONSECIONARIA (ID_CONSECIONARIA)
go

alter table CLIENTES
   add constraint FK_CLIENTES_CONSECION_CONSECIO foreign key (ID_CONSECIONARIA)
      references CONSECIONARIA (ID_CONSECIONARIA)
go

alter table COTIZACIONES
   add constraint FK_COTIZACI_COTIZACIO_ASESORES foreign key (ID_ASESOR)
      references ASESORES (ID_ASESOR)
go

alter table COTIZACIONES
   add constraint FK_COTIZACI_COTIZACIO_CARROS foreign key (CHASIS)
      references CARROS (CHASIS)
go

alter table COTIZACIONES
   add constraint FK_COTIZACI_COTIZACIO_CLIENTES foreign key (CEDULA)
      references CLIENTES (CEDULA)
go

INSERT INTO CONSECIONARIA(ID_CONSECIONARIA,DIRECCION,HORARIO_TALLERES,HORARIO_SHOWROOM,_CONTACTO_VENTAS,CONTACTO_PBX,CONTACTO_POSTVENTA)
VALUES (1,'Av. Eloy Alfaro entre Gaspar de Villaroel','Lunes a viernes: 8h00 a 17h00 S�bados: Previa cita Domingo: Cerrado','Lunes a viernes: 9h00 a 18h00 S�bados: 10h00 a 14h00 Domingo:  Cerrado', '096 416 0000', '096 403 0030', '096 416 4120'),
(2, 'Av Juan Tanca Marengo Km 1.5 Frente a Conauto', 'Lunes a Viernes: 07h30 a 17h00 S�bado:  Previa Cita Domingo: Cerrado', 'Lunes a viernes: 9h00 a 18h00 S�bados: 10h00 a 14h00 Domingo:  Cerrado', '096 416 0000', '096 403 0030', '096 416 4120'),
(3, 'Av. Via a Samborond�n Km 1.5, CC Village', 'No existe horario', 'Lunes a s�bado:10h00 a 21h00 Domingo: 10h00 a 20h00', '096 416 0000', '096 403 0030', 'Ninguno'),
(4, 'Av Juan Tanca Marengo Km 1.5 Frente a Conauto.', 'Lunes a Viernes: 07h30 a 17h00 S�bado: Previa Cita Domingo: Cerrado', 'Lunes a viernes: 10h00 a 19h00 S�bados: 10h00 a 18h00 Domingo: 11h00 a 16h00', '096 416 0000', '096 403 0030', '096 416 4120'),
(5, 'CC Scala Shopping, Planta Baja', 'No existe horario', 'Lunes a jueves:10h00 a 20h30 Viernes y s�bado: 10h00 a 21h00 Domingo: 10h00 a 20h00', '096 416 0000', '096 403 0030', 'Ninguno'),
(6, 'Av Gil Ramirez D�valos y de Las Laderas. ', 'Lunes a viernes: 8h00 a 17h00 S�bados: Previa cita Domingo: Cerrado', 'Lunes a viernes: 9h00 a 18h00 S�bados: 10h00 a 14h00 Domingo:  Cerrado', '096 416 0000', '096 403 0030', '096 416 4120')

INSERT INTO concesionaria_peugeot.dbo.CLIENTES(CEDULA,ID_CONSECIONARIA,NOMBRES,APELLIDOS,FECHA_NACIMIENTO,TELEFONO,CIUDAD_RESIDENCIA,EMAIL)
VALUES (1746860979, 2, 'Gustie Eadith', 'Causer, Gilderoy', '1971-07-30', '0967204773', 'Milagro', 'egilderoy0@last.fm'),
(1749439869, 3, 'Titos Deedee', 'Charge Maylard', '2007-10-18', '0964258056', 'Cuenca', 'dmaylard1@businessweek.com'),
(1710498649, 5, 'Holly-anne Nickolaus', 'O Dornan Shortcliffe', '1967-12-12', '0985517946', 'Cuenca', 'nshortcliffe2@google.de'),
(1722014069, 5, 'Brandie Briggs', 'Jenney Sawney', '2015-07-31', '0978855467', 'Santo Domingo', 'bsawney3@spotify.com'),
(1757397109, 1, 'Etheline Kipp', 'Jacklings Jiru', '1961-10-13', '0943594683', 'Tulc�n', 'kjiru4@ft.com'),
(1766975779, 1, 'Daisey Evyn', 'MacIan Puddifer', '2020-01-15', '0992332578', 'Santo Domingo', 'epuddifer5@hhs.gov'),
(1744024099, 5, 'Ignaz Richart', 'Wiles Roads', '1978-12-15', '0926732723', 'Machala', 'rroads6@csmonitor.com'),
(1706872789, 6, 'Hermie Raff', 'Emnoney Braemer', '2005-08-18', '0995487956', 'Salinas', 'rbraemer7@sohu.com'),
(1784144019, 3, 'Kile Lindsay', 'Kolodziejski Ruppel', '1972-05-13', '0966799832', 'Babahoyo', 'lruppel8@yolasite.com'),
(1790316349, 1, 'Trish Corrie', 'Dimbylow Palethorpe', '2013-05-22', '0972929345', 'Guayaquil', 'cpalethorpe9@symantec.com'),
(1733396349, 4, 'Sibylle Jean', 'Jaynes Limon', '2001-01-06', '0983100857', 'Tulc�n', 'jlimona@businessinsider.com'),
(1754446659, 6, 'Seward Dilly', 'Agdahl Stobie', '2008-09-20', '0917569283', 'Portoviejo', 'dstobieb@woothemes.com'),
(1782426199, 4, 'Gui Luke', 'Christauffour Tregale', '1989-03-21', '0927431119', 'Milagro', 'ltregalec@csmonitor.com'),
(1724576129, 6, 'Dorri Myrtia', 'Wimpey Gotobed', '1984-05-22', '0963059832', 'Quevedo', 'mgotobedd@dyndns.org'),
(1781356057, 3, 'Reilly Gordon', 'Bestall Reason', '1989-05-08', '0937027740', 'Ambato', 'greasone@sourceforge.net'),
(1733073644, 3, 'Rossy Ancell', 'Butte Lemonby', '1981-12-04', '0996795916', 'Machala', 'alemonbyf@biblegateway.com'),
(1759496859, 3, 'Stevie Cary', 'Lowdes Skokoe', '1967-11-18', '0912627279', 'Ibarra', 'cskokoeg@mozilla.com'),
(1760306479, 6, 'Cathi Mattias', 'Trunkfield Alderwick', '1975-04-22', '0962433843', 'Guayaquil', 'malderwickh@spiegel.de'),
(1711346549, 6, 'Car Elva', 'Colbourne Durie', '2017-01-08', '0911683861', 'Cuenca', 'eduriei@icio.us'),
(1782716529, 6, 'Reagen Drusi', 'Mcwhinney Hourstan', '1983-06-05', '0934111754', 'Riobamba', 'dhourstanj@sciencedaily.com'),
(1734316339, 5, 'Oona Ivankin', 'Tiffi Barnewall', '1963-07-09', '0984863184', 'Guayaquil', 'tbarnewallk@techcrunch.com'),
(1794190099, 6, 'Rory Dobey', 'Myrilla Gard', '1978-03-21', '0924836115', 'Riobamba', 'mgardl@state.tx.us'),
(1705530679, 3, 'Willis Gaine', 'Cass Broad', '1964-05-29', '0916654141', 'Otavalo', 'cbroadm@rakuten.co.jp'),
(1714014039, 6, 'Ulysses Cherrie', 'Gregor Spurdens', '1965-05-26', '0942263392', 'Ambato', 'gspurdensn@jugem.jp'),
(1793668909, 6, 'Koo Gaythwaite', 'Marybeth Clohissy', '1970-01-28', '0937614692', 'Santo Domingo', 'mclohissyo@abc.net.au'),
(1756832093, 3, 'Farlay Katti', 'Dods Slayny', '2000-03-16', '0919456787', 'Machala', 'kslaynyp@xinhuanet.com'),
(1785569696, 4, 'Frankie Filipychev', 'Casi Bartlett', '1992-02-13', '0998104250', 'Tulc�n', 'cbartlettq@prweb.com'),
(1729963498, 3, 'Joyan Davydenko', 'Gabie Gravenor', '1989-12-17', '0945283356', 'Quevedo', 'ggravenorr@yahoo.com'),
(1744466996, 5, 'Rog Gynni', 'Brander Deinhardt', '2022-06-03', '0963385448', 'Portoviejo', 'bdeinhardts@shop-pro.jp'),
(1739357596, 3, 'Alaine D''Agostino', 'Kane Surplice', '2023-08-24', '0941696979', 'Loja', 'ksurplicet@whitehouse.gov'),
(1703453099, 4, 'Brana Fryatt', 'Daniel Wynes', '2013-11-26', '0959536301', 'Quevedo', 'dwynesu@webeden.co.uk'),
(1710075696, 6, 'Lazar Martinolli', 'Mitzi Wittier', '2000-06-08', '0939252342', 'Otavalo', 'mwittierv@bravesites.com'),
(1706422194, 6, 'Giorgia Yare', 'Audie Scola', '2023-12-30', '0973508220', 'Machala', 'ascolaw@si.edu'),
(1702449892, 6, 'Gifford Thrussell', 'Sheilah McQuade', '1995-02-28', '0918237407', 'Guayaquil', 'smcquadex@theglobeandmail.com'),
(1769889493, 5, 'Christopher Caldero', 'Nathanial Quinney', '1973-07-29', '0993041725', 'Ambato', 'nquinneyy@oaic.gov.au'),
(1713759393, 2, 'Samara Gauson', 'Yolane Please', '1991-01-19', '0991946000', 'Santo Domingo', 'ypleasez@guardian.co.uk'),
(1755249999, 3, 'Annalise Beer', 'Tibold Colledge', '2002-12-30', '0954892952', 'Otavalo', 'tcolledge10@ed.gov'),
(1741613697, 4, 'Wendye Freemantle', 'Yvonne Yankin', '1967-01-29', '0997448125', 'Quito', 'yyankin11@reference.com'),
(1787121493, 3, 'Malinde Cicullo', 'Nan Cyster', '1963-10-19', '0924002528', 'Salinas', 'ncyster12@digg.com'),
(1756227998, 1, 'Nowell Flooks', 'Wolfie Mole', '1971-05-19', '0994006192', 'Latacunga', 'wmole13@archive.org'),
(1756953093, 4, 'Kym Comizzoli', 'Rodney Glaister', '1994-05-10', '0926781359', 'Riobamba', 'rglaister14@army.mil'),
(1764700796, 5, 'Kayla Jeanelle', 'Prudence Mattioli', '10/22/2000', '0995832010', 'Salinas', 'jmattioli15@addthis.com'),
(1766296893, 1, 'Averil Seymour', 'Pittet Aughtie', '12/14/1961', '0914420036', 'Portoviejo', 'saughtie16@multiply.com'),
(1773577099, 3, 'Goldie Ryon', 'Parncutt Beckles', '04/04/1969', '0993471793', 'Riobamba', 'rbeckles17@bloglovin.com'),
(1751744899, 4, 'Vaughan Bart', 'Rodwell Brookshaw', '03/07/1985', '0965227569', 'Riobamba', 'bbrookshaw18@jigsy.com'),
(1763794497, 4, 'Taite Roth', 'Ruegg Coulsen', '10/10/2015', '0962131566', 'Portoviejo', 'rcoulsen19@ameblo.jp'),
(1709432393, 3, 'Loise Emogene', 'Bedford Chadderton', '06/12/2008', '0965394500', 'Milagro', 'echadderton1a@skyrock.com'),
(1709834596, 1, 'Bronny Erich', 'Brashier Semiras', '04/19/2011', '0926990941', 'Guayaquil', 'esemiras1b@desdev.cn'),
(1730713496, 5, 'Dulcea Enrico', 'Oller Coward', '08/10/2005', '0914550893', 'Ibarra', 'ecoward1c@smh.com.au'),
(1787358190, 1, 'James Zita', 'Lunck Hirtz', '08/18/1996', '0968633898', 'Latacunga', 'zhirtz1d@blinklist.com'),
(1783792191, 5, 'Lynett Kaye', 'Connow Lydon', '07/02/1982', '0944348780', 'Babahoyo', 'klydon1e@github.io'),
(1769700394, 2, 'Kai Issi', 'Walter Ortler', '11/09/1973', '0921643730', 'Ibarra', 'iortler1f@delicious.com'),
(1720317596, 2, 'Judd Andrus', 'La Rosa Worster', '07/14/1993', '0921496274', 'Milagro', 'aworster1g@wikia.com'),
(1729692093, 2, 'Nancie Leshia', 'Braidon Attoe', '08/12/1995', '0989762239', 'Ambato', 'lattoe1h@yellowbook.com'),
(1771168090, 4, 'Benny Any', 'Bierling De Carteret', '02/08/1963', '0914601090', 'Quevedo', 'adecarteret1i@chron.com'),
(1743425695, 6, 'Vasili Marlena', 'Arnao Rawlinson', '04/01/1980', '0966503651', 'Milagro', 'mrawlinson1j@g.co'),
(1756297593, 6, 'Fredia Terrijo', 'Gumey Joriot', '05/27/2006', '0993287960', 'Esmeraldas', 'tjoriot1k@ihg.com'),
(1721543193, 6, 'Pamella Hesther', 'Essex Roslen', '02/14/2009', '0953596214', 'Ambato', 'hroslen1l@bloglines.com'),
(1764957696, 3, 'Kendrick Christophorus', 'Salan Fone', '01/09/1962', '0927472573', 'Ambato', 'cfone1m@flickr.com'),
(1703179096, 6, 'Bree Bobby', 'Richen Dinley', '03/23/2018', '0957285235', 'Riobamba', 'bdinley1n@sina.com.cn'),
(1749280796, 3, 'Granthem Lucille', 'Johnsson Pocke', '02/28/1975', '0951029046', 'Guayaquil', 'lpocke1o@reference.com'),
(1724864793, 4, 'Clo Leigh', 'Greves Synan', '02/06/2023', '0964755057', 'Tulc�n', 'lsynan1p@miitbeian.gov.cn'),
(1730851494, 5, 'Auberta Teofila', 'Spencer Keam', '01/18/2000', '0956930148', 'Cuenca', 'skeam1q@multiply.com'),
(1726790190, 1, 'Marchelle Vernita', 'Vasilenko Ryott', '03/19/1977', '0950489237', 'Ibarra', 'vryott1r@blogspot.com'),
(1733697293, 4, 'Leslie Dar', 'Gallimore Atherley', '06/13/1994', '0945642513', 'Ambato', 'gatherley1s@wordpress.com'),
(1774860093, 5, 'Russ Lillie', 'Grosvenor Carmon', '01/25/2010', '0972104674', 'Loja', 'gcarmon1t@businessweek.com'),
(1727260092, 4, 'Corly Roby', 'Klee Marchelli', '02/18/2020', '0912699771', 'Riobamba', 'rmarchelli1u@dmoz.org'),
(1750579696, 1, 'Holly Ozzy', 'Percifer Ellis', '06/03/1979', '0956634398', 'Nueva Loja', 'oellis1v@nyu.edu'),
(1745937697, 2, 'Jessie Graehme', 'Jenney Thomasset', '06/03/1982', '0974928911', 'Milagro', 'gthomasset1w@webmd.com'),
(1765373897, 4, 'Muffin Amye', 'Tuft Paulusch', '07/24/2019', '0989251355', 'Otavalo', 'apaulusch1x@constantcontact.com'),
(1785207197, 6, 'Thatcher Simonette', 'Daffey Earingey', '02/20/1984', '0934874645', 'Ibarra', 'searingey1y@weebly.com'),
(1762727990, 1, 'Barton Delora', 'Dinsale Biaggioni', '08/20/2021', '0972092596', 'Tulc�n', 'dbiaggioni1z@so-net.ne.jp'),
(1710635897, 3, 'Crystal Bordy', 'Isaksson Charon', '10/24/2011', '0986767125', 'Ambato', 'bcharon20@oaic.gov.au'),
(1737160896, 1, 'Bartholomew Robina', 'Hynard Odell', '11/27/1972', '0955957871', 'Quevedo', 'rodell21@cbc.ca'),
(1756733897, 3, 'Jermain Lydia', 'Barszczewski Corkill', '12/25/2002', '0987141327', 'Nueva Loja', 'lcorkill22@themeforest.net'),
(1797149790, 1, 'Modesty Juanita', 'Rendall Branch', '11/29/1965', '0955697634', 'Riobamba', 'jbranch23@tiny.cc'),
(1757481697, 1, 'Sully Nicolai', 'Derell Bugbird', '04/21/2018', '0957577621', 'Quevedo', 'nbugbird24@apache.org'),
(1747406791, 1, 'Dougy Max', 'Caseborne Palfrie', '05/01/2018', '0927747097', 'Esmeraldas', 'mpalfrie25@bluehost.com'),
(1769510697, 6, 'Richie Ulrika', 'Edeler Roon', '10/24/1983', '0966883430', 'Ambato', 'uroon26@ycombinator.com'),
(1766772998, 1, 'Sibeal Wilma', 'Piburn Syred', '10/31/2001', '0999761128', 'Ibarra', 'wsyred27@goo.ne.jp'),
(1784392694, 3, 'Lenna Harvey', 'Iorns Mulholland', '01/30/1968', '0957830393', 'Milagro', 'hmulholland28@ucoz.com'),
(1792838494, 5, 'Christy Kippie', 'Murty Bowdery', '06/17/1992', '0991163275', 'Ibarra', 'kbowdery29@virginia.edu'),
(1707933598, 4, 'Berri Cullan', 'Roberds Perrins', '10/29/1983', '0977382183', 'Nueva Loja', 'cperrins2a@cisco.com'),
(1708557493, 5, 'Aurie Maryl', 'Pentin Armsden', '09/01/2021', '0987685508', 'Milagro', 'marmsden2b@wsj.com'),
(1780072897, 1, 'Oberon Jolee', 'Edards Haensel', '02/23/2021', '0943418510', 'Quevedo', 'jhaensel2c@wufoo.com'),
(1775343695, 6, 'Bobine Danya', 'Allans Korneichuk', '11/27/2007', '0937979399', 'Ibarra', 'dkorneichuk2d@desdev.cn'),
(1747797690, 5, 'Burlie Zondra', 'Cockerell Nesbitt', '09/28/2013', '0967251073', 'Latacunga', 'znesbitt2e@marriott.com'),
(1799141391, 6, 'Clem Si', 'Pucknell Gonoude', '04/01/2021', '0937023550', 'Ambato', 'sgonoude2f@indiegogo.com'),
(1734561899, 2, 'Adrian Maire', 'Torrens Saldarini', '08/15/1980', '0967452390', 'Loja', 'atsaldarini30@webmd.com'),
(1762985999, 5, 'Della Zora', 'Fridrich Gaskins', '11/09/1995', '0913485623', 'Quito', 'dgaskins31@rambler.ru'),
(1745673499, 3, 'Evelyn Corinne', 'Bessette Ainsworth', '05/19/1999', '0937650421', 'Cuenca', 'cainsworth32@scientificamerican.com'),
(1756728499, 1, 'Franklin Leslie', 'Brewer Richmond', '03/13/1984', '0948725604', 'Manta', 'lrichmond33@weather.com'),
(1728159499, 6, 'Harrison Clarence', 'Fletcher Amador', '02/11/1990', '0963108534', 'Portoviejo', 'cfletcher34@blogspot.com'),
(1794620199, 4, 'Jodie Janel', 'Valcourt Burnside', '09/30/1993', '0912340895', 'Ambato', 'jburnside35@github.com'),
(1783456799, 5, 'Gail Britta', 'Lovelace Salgado', '01/21/2002', '0976358294', 'Quito', 'bsalgado36@sciencedirect.com'),
(1772348699, 2, 'Imelda Desiree', 'Greenfield Talamantes', '07/28/1987', '0936546127', 'Latacunga', 'dtalamantes37@delicious.com'),
(1703462899, 3, 'Roger Valerie', 'Romero Krenz', '10/16/1975', '0956207289', 'Loja', 'vkrenz38@woothemes.com'),
(1739258499, 1, 'Tanya Joan', 'Farrelly Lesage', '12/23/1994', '0968574203', 'Esmeraldas', 'jlesage39@shutterfly.com'),
(1745968399, 6, 'Steven Hayward', 'Denham Wilkerson', '08/05/1988', '0982345032', 'Tulc�n', 'wwilkerson40@disqus.com'),
(1793471699, 5, 'Emily Wynne', 'Vines Vachon', '04/22/1996', '0924783891', 'Ibarra', 'wvachon41@hibu.com');

INSERT INTO concesionaria_peugeot.dbo.ASESORES(ID_ASESOR, ID_CONSECIONARIA, CEDULA_ASESOR, NOMBRES, APELLIDOS, EMAIL, SUELDO, TOKEN_CREDENCIAL, PORCENTAJE_COMISION) 
VALUES (1,2,843676635,'Barby Woodman','Uttermare McMichan','wmcmichan0@pcworld.com',587.76,'AZ90 XHWF BVN5 CBQL PBUJ IO5Z PDRV',20),
    (2,3,1412964067,'Maryjo Lita','Imason Gammade','lgammade1@google.nl',644.62,'GB27 OXAM 4521 1593 5031 74',15),
    (3,3,1704564022,'Jacquie Alisha','Hudless Rollings','arollings2@va.gov',709.04,'PT15 4552 2011 0955 0192 3456 9',15),
    (4,3,715807056,'Anderea Zedekiah','Heare Verlander','zverlander3@ox.ac.uk',586.71,'PK73 QVAW ME0Q E6XQ 93OO 0BSR',15),
    (5,5,722908206,'Di Harriett','Fairman Eringey','heringey4@huffingtonpost.com',636.98,'FI21 1477 2228 6138 10',15),
    (6,3,2257542244,'Jonie Genovera','Swetland Longlands','glonglands5@unicef.org',676.08,'LV30 YLQS 8CRV WKHQ GLUW 7',20),
    (7,4,624004356,'Edie Friedrick','Curado Boulden','fboulden6@ustream.tv',990.83,'DK41 8862 3116 5232 87',15),
    (8,5,469428113,'Devin Dill','Trethowan Pratte','dpratte7@163.com',731.98,'MT37 FHAI 3505 334K Q7O1 TJR7 PAYU RQL',10),
    (9,1,1311251960,'Edwin Oona','MacAllan Comberbeach','ocomberbeach8@meetup.com',992.73,'ES17 8416 6503 9874 8524 8101',5),
    (10,4,1246704677,'Rance Fletch','Arderne Badam','fbadam9@xing.com',537.84,'CR14 9630 5669 7392 3198 2',10),
    (11,5,1667040575,'Merrick Sada','Bahlmann de Nore','sdenorea@columbia.edu',992.66,'PS06 VOSH M1FA IMQ4 WIRS VHVQ 1BYD Y',20),
    (12,2,2006376882,'Gilligan Sallie','Brogden Locarno','slocarnob@twitter.com',627.33,'FR54 4280 7956 347X 8NPP MEZV V81',10),
    (13,6,655007584,'Gretel Noni','Roskelley Soares','nsoaresc@time.com',718.51,'HR06 3029 3244 9697 2890 2',15),
    (14,1,2405408494,'Jeromy Gareth','Klosterman Beyne','gbeyned@creativecommons.org',924.14,'RO77 RAJL L3CI 5R6A TFWP QBVP',5),
    (15,2,937296676,'Ray Gabriele','Wyness Wadhams','gwadhamse@toplist.cz',762.35,'BE41 8134 8085 1547',15),
    (16,4,1722548091,'Sybil Korney','Lidbetter Entwisle','kentwislef@123-reg.co.uk',720.70,'DE03 3800 4646 4796 5095 33',20),
    (17,1,1924327462,'Vonny Pierre','Weiss Dinsey','pdinseyg@slashdot.org',946.67,'EE48 6410 6112 0982 9800',20),
    (18,5,1467144208,'Manya Kalvin','Witty Mauditt','kmauditth@acquirethisname.com',847.75,'TR34 2790 06HP UXDY ROJN MTEH 1N',5),
    (19,1,1862011759,'Evin Carmencita','Scryne Fordy','cfordyi@independent.co.uk',637.19,'GR78 7420 886C JVXD PD4A QTUH AMJ',20),
    (20,6,2317793481,'Mellisa Wiatt','Delaprelle Antrim','wantrimj@usa.gov',698.02,'FR83 6417 4240 82N3 2YTS LITG S09',5),
	    (21,5,710217390,'Jemmy Cesare','Bowker Dimeloe','cdimeloek@amazon.de',685.37,'PL72 8538 3489 0490 4789 7762 5075',10),
    (22,4,1741823424,'Manda Caz','Gillebride Mallia','cmallial@ucoz.com',923.44,'ES47 1269 1925 3886 5485 3343',15),
    (23,3,1870661343,'Alfy Cord','McGarry Perrelle','cperrellem@tinyurl.com',635.25,'GB48 UWKV 1178 4281 5041 01',20),
    (24,2,497369927,'Dane Allister','Nowland Dunsire','anowslanddunsiren@angelfire.com',782.11,'AT80 2484 8911 9484 0458',15),
    (25,6,1098781348,'Lauritz David','Muslim Sudlow','dmuslimos@tripadvisor.com',847.91,'SE63 3514 0917 9464 5158 6395',10),
    (26,4,1442096592,'Jeanelle Ingrid','Attiwill Wetherick','iwetherickp@elpais.com',941.78,'IT36 R493 2743 8159 CCGS K99A PKZ',20),
    (27,3,1427326419,'Thornie Helmut','Abrams Judd','habramsq@unesco.org',725.03,'BG51 6884 3514 0648 4445 13',10),
    (28,2,2364050974,'Mufinella Ed','Baily Dodridge','ebailyr@apple.com',796.99,'SA17 83X7 7QXJ CYZK 2LK4 5GLR',15),
    (29,6,1244740032,'Christyna Kay','Jaray Cadogan','kjaraycadogans@seesaa.net',728.18,'NL21 5087 4973 3209',5),
    (30,1,1521374573,'Timothy Broddie','Widder Wheatland','bwheatlandt@wired.com',789.34,'FI94 4828 5011 8741 96',20),
    (31,5,1867214832,'Morton Roseline','Rosenbush Domnin','rrosenbushu@house.gov',992.21,'NO30 2488 1405 988',15),
    (32,6,1420176575,'Myrwyn Belva','De Laspee Servant','bservantv@barnesandnoble.com',816.43,'LU98 5367 8222 2784 0080',15),
    (33,3,1266061230,'Fabio Donovan','Pretti Guise','dguisew@google.co.uk',699.15,'CH31 0928 5467 9101 1157 4',10),
    (34,4,2022840498,'Whitney Lucia','Argrave Bellwood','lbellwoodx@ucoz.com',963.27,'EE59 5535 0046 1931 6378',15),
    (35,1,1375168966,'Verney Rowena','Cumbers Ibbott','rcumbersy@ovh.net',580.12,'IE73 2356 5205 7890 0340 63',10),
    (36,2,1634829671,'Robbie Garland','Buswell Mohring','gmohringz@cornell.edu',841.67,'HU04 3847 6543 2850 7643 7915 2572',15),
    (37,5,1496587184,'Salomo Edmund','Eckels Bulbrook','ebulbrooka0@360.cn',697.29,'IS64 1092 4961 0233 7428 3505 53',5),
    (38,3,1665629893,'Cameron Pam','Snoddin Ogus','pogusa1@hubpages.com',724.85,'GR57 5687 416X JXYG S7ML 0FCP 58C',20),
    (39,6,1136594782,'Michalina Freddi','Passifant Ancliffe','fpassifanta2@diigo.com',901.92,'RO27 AUVN IM9M TGRX Q5OA WGK7',15),
    (40,4,2322848100,'Reese Garret','Scriver Conachie','gconachiea3@aboutads.info',845.78,'CZ22 4373 0836 7254 3784 2812',5),
	    (41,1,1878163928,'Ric Don','Lashbrooke Byles','dbylesa4@1688.com',932.67,'PL62 4486 2342 7855 3490 5398 4072',10),
    (42,2,1394736249,'Dena Pam','Stowman Oxtoby','soxtobya5@hao123.com',613.54,'DK32 3087 0828 3958 16',20),
    (43,3,1543879123,'Rurik Nick','Butt Gowry','ngowrya6@google.co.jp',889.11,'FR41 6146 5369 66ZH ZUOM PQDK L11',5),
    (44,4,1412736482,'Selma Hugh','Yankish Bolitho','hbolithoa7@opera.com',709.19,'PT42 4905 0069 2548 4701 6333 5',15),
    (45,6,1763946210,'Lyndsie Amanda','Leverson Bendy','abendya8@oaic.gov.au',845.52,'BE94 3659 0162 2911',20),
    (46,5,1947235648,'Ramonia Frank','Hulcoop Blondelle','fblondellea9@princeton.edu',901.43,'EE69 9574 3733 5588 8733',5),
    (47,4,1693481276,'Richie Maud','Howerd Dudny','mdudnyaa@homestead.com',773.69,'ES39 3589 7394 9141 5745 0238',15),
    (48,3,1972345123,'Theo Naomi','Jephcote Diben','ndibenab@umich.edu',625.37,'CZ75 0983 9157 1801 6743 0311',10),
    (49,1,1473962782,'Nina Johan','Burnip Saxton','jsaxtonac@jalbum.net',811.22,'SK64 6966 4625 7196 0473 7210',15),
    (50,2,1347826432,'Xavier Hugo','Faldo Cassedy','hcassedyad@xing.com',897.74,'LV47 IYZA PSFP XYMR G0WQ G',20),
    (51,5,1528374619,'Ike Emeline','Ridley Baty','ebatyae@discuz.net',762.81,'CY84 4628 6310 IOEQ QRCC 75VO DNW9',5),
    (52,6,1432817625,'Jeanna Violet','Gouldstone Hully','vhullyaf@cbc.ca',982.46,'FI53 4056 7074 1337 56',10),
    (53,4,1683752109,'Benita Irene','Olman Dulake','idulakeag@thetimes.co.uk',719.35,'MT62 QJEG 5139 1KXS FOWK SWFT XYXE X5U',15),
    (54,3,1384781623,'Wendye Ramon','Hindmore Ziemsen','rziemsenah@springer.com',801.89,'RO62 AJRI 3UUE Q2UR 1E0F VFYQ',20),
    (55,2,1248391762,'Maynord Nancy','Blott Pitcher','npitcherai@mozilla.com',643.29,'DE24 1358 5271 7341 5869 00',5),
    (56,6,1523847129,'Anastasia George','Humm Fytche','gfytcheaj@list-manage.com',824.77,'GB63 XOBC 4012 9727 0472 38',10),
    (57,5,1382164789,'Conrade Charles','Wringe Pulman','cpulmanak@ucoz.ru',671.19,'NL24 ABNA 5476 7615 41',15),
    (58,4,1657832912,'Rowe Les','Brouwer Durning','ldurningal@weebly.com',954.13,'PT77 8995 1937 7633 9704 5465 3',20),
    (59,1,1829371482,'Pamela Ella','Sawyers Medcalf','emedcalfam@amazon.co.jp',899.25,'LU02 1323 2216 5310 5459',15),
    (60,3,1258472193,'Kristos Henry','Gozney Landeg','hlandegan@pinterest.com',835.47,'LT62 7048 6743 2490 0138',5),
    (61,6,1972845123,'Quentin Norah','Kembry Leigh','nleighao@deliciousdays.com',961.33,'SE57 8178 4823 6519 5061 8991',10),
    (62,2,1324736119,'Brennan Justin','Brabourne Allot','jallotap@who.int',659.71,'AT41 5811 7297 5705 9876',20),
    (63,4,1647294829,'Valerie Logan','Boon Decoste','ldecosteaq@nyu.edu',782.56,'SI56 8386 9248 4265 118',15),
    (64,5,1475921643,'Joan Lillian','Standell Polton','lpoltonar@vk.com',894.62,'NO18 7434 5887 731',10),
    (65,3,1672345890,'Wilma Arnold','Oades Melesk','ameleskas@cornell.edu',780.45,'BG94 5574 8395 1851 2355 70',5),
    (66,6,1334856172,'Sheree Clarence','Bolino Kinnach','ckinnachat@google.nl',986.14,'CH27 7933 1256 3248 3205 5',20),
    (67,1,1529384567,'Garrick Maribel','Mabb Leyland','mleylandau@webnode.com',708.63,'FI73 2589 1451 8125 33',15),
    (68,2,1437294562,'Merl Humphrey','Mason Crennan','hcrennanav@xing.com',935.22,'CZ54 8341 3809 5266 7658 9080',10),
    (69,4,1957294857,'Ellwood Kelvin','Lemonnier Hayball','khayballaw@instagram.com',787.34,'GR24 7674 803O MWLR F5RP O1EO 91N',5),
    (70,6,1274938210,'Brion Elsa','Heinecke Mellow','emellowax@epa.gov',899.58,'SA58 95LD 6PCP X79J ZZ10 N6LE',20),
	    (71,3,1629487312,'Arlina Trevor','Simpkiss Beszant','tbeszantay@businessinsider.com',934.11,'IE27 ABNO 7089 5331 4192 95',10),
    (72,2,1583729145,'Dorrie Jacob','Southway Steane','jsteaneaz@reuters.com',716.35,'PL83 3037 7544 1561 7083 9828 6255',5),
    (73,4,1447382941,'Rana Jake','Dunkerton Capini','jcapinib0@biblegateway.com',859.67,'IT53 S498 8874 9869 UGGK VKXL 2XB',20),
    (74,6,1873642951,'Martie Allie','Algy Dinely','adinelyb1@economist.com',928.45,'ES49 9231 7185 2791 2517 5646',15),
    (75,1,1753814927,'Christye Patrick','Fancott Ager','pagerb2@cloudflare.com',809.53,'DE72 3787 1860 4471 0818 78',10),
    (76,5,1367824910,'Helena Douglas','Manlowe Briston','dbristonb3@oaic.gov.au',763.22,'LU95 0125 8046 9752 6746',5),
    (77,4,1528734619,'Boycie Karl','Leiper Scopyn','kscopynb4@list-manage.com',810.75,'PT50 3847 8393 8048 5507 3144 4',15),
    (78,3,1639728431,'Charis Joel','Holdon Fenkel','jfenkelb5@eventbrite.com',742.18,'AT08 4779 6809 2435 9218',20),
    (79,6,1897326412,'Jobey Greg','Trimming Downs','gdownsb6@wiley.com',876.39,'GB17 VOQL 1806 8794 7587 32',10),
    (80,2,1429385627,'Tana Kim','Varden Snell','ksnellb7@businessweek.com',945.41,'BE30 4031 2314 1746',5),
    (81,1,1549283749,'Grady Yvonne','Menchenton Filochov','yfilochovb8@cargocollective.com',793.88,'FI90 5804 8824 9051 68',15),
    (82,3,1693821476,'Curt Tanya','Slade Wilkenson','twilkensonb9@tamu.edu',701.64,'NL72 INGB 0656 8080 31',20),
    (83,4,1379264831,'Hugibert Davis','Rosindale Wyant','dwyantba@house.gov',923.25,'GR96 6892 580Z YYT9 E4N5 8QLN G6C',5),
    (84,6,1857429813,'Marline Ashton','Hubbley Kersting','akerstingbb@goo.ne.jp',974.67,'BG12 9946 2251 7654 2157 37',10),
    (85,5,1398472163,'Jayce Tory','Wetherburn Guider','tguiderbc@geocities.jp',849.35,'DK67 2272 8224 4048 82',15),
    (86,2,1629348721,'Daisy Lionel','Brookebank Coutthart','lcoutthartbd@ovh.net',764.89,'RO38 MWUE 2XLM RVGZ HAOX H3GJ',20),
    (87,4,1483927610,'Ophelie Walter','Ratchford Whitesel','wwhiteselbe@spotify.com',705.47,'CY39 6051 0513 CHTG TLHG 2KAG VHXQ',10),
    (88,1,1974836152,'Eudora Felix','Wayland Sephton','fsephtonbf@slate.com',887.78,'EE92 7924 0346 6632 1837',5),
    (89,3,1753846291,'Tam Jerome','Bindrett Selvey','jselveybg@narod.ru',799.14,'CZ12 9688 5445 3348 6310 6605',15),
    (90,5,1429372164,'Verge Courtney','Skough Bentley','cbentleybh@java.com',833.92,'PT84 7372 8943 5050 1650 5186 3',20),
    (91,6,1374893275,'Ronald Morgan','Plaidstone Claeson','mclaesonbi@xing.com',971.48,'SE62 7605 4590 7934 1197 5874',5),
    (92,4,1437265492,'Lanita Avery','Mariner McFarlane','amcfarlanebj@cbc.ca',763.12,'LT60 1172 5169 2075 0743',10),
    (93,2,1257834690,'Alie Bert','Besters Reast','breastbk@patch.com',920.76,'MT56 MTGR 8923 4TFO 6V7M 6Q0M RWYC 8WD',15),
    (94,1,1947382641,'Sigrid Todd','Grigory Scarisbrick','tscarisbrickbl@mozilla.org',835.28,'LU78 7355 8935 0676 8128',20),
    (95,3,1583296742,'Erasmus Heather','Killock Hawkeridge','hhawkeridgebm@ocn.ne.jp',881.66,'SK21 7133 7116 8595 4582 6575',10),
    (96,6,1647382916,'Giles Mark','Borkin Bevington','mbevingtonbn@sohu.com',902.34,'PL17 6502 1705 8637 5243 9379 9758',5),
    (97,2,1974836214,'Angelina Stuart','Welham Spellesy','sspellesybo@webs.com',945.67,'FI59 4977 1595 2536 09',15),
    (98,4,1892745621,'Lila Sarah','Bing Jaggard','sjaggardbp@guardian.co.uk',873.91,'SA74 77RH 6WGV H49V R63A 3V2D',20),
    (99,5,1468294731,'Reggie Pearl','Carnall Holes','pholesbq@nbcnews.com',812.43,'BG62 1475 9624 9810 2355 95',10),
    (100,1,1829374682,'Patrice Rena','Ruddimann Tommis','rtommisbr@time.com',911.57,'ES90 7697 3157 2457 6045 3893',15);

INSERT INTO concesionaria_peugeot.dbo.CARROS(CHASIS, ID_CONSECIONARIA, NOMBRE_MODELO, TIPO_TRANSMISION, COLOR, TIPO_COMBUSTIBLE, CONSUMO, PRECIO_STANDARD, YEAR)
VALUES('A123B456C789D012E', 1, 'Peugeut 208', 0, 'Azul', 'PureTech' , '5.3L/100km', 24990.00,2019),
('B234C567D890E123F', 2, 'Peugeut 2008', 0, 'Azul', 'PureTech' , '5.3L/100km', 28990.00,2019),
('C345D678E901F234G', 3, 'Peugeut 3008', 0, 'Azul', 'PureTech' , '6.4L/100km', 39990.00,2023),
('D456E789F012G345H', 4, 'Peugeut SUV 5008', 0, 'Azul', 'PureTech' , '6.4L/100km', 39990.00,2023),
('E567F890G123H456I', 5, 'Peugeut LANDTREK', 0, 'Azul', 'PureTech' , '6.71L/100km', 47990.00,2023);


INSERT INTO concesionaria_peugeot.dbo.COTIZACIONES(ID_COTIZACION, ID_ASESOR, CHASIS, CEDULA, FECHA) 
VALUES (1, 35, 'A123B456C789D012E', 1745092031, '9/16/2024'),
(2, 45, 'B234C567D890E123F', 1756728472, '5/3/2024'),
(3, 67, 'C345D678E901F234G', 1769234071, '2/18/2024'),
(4, 89, 'D456E789F012G345H', 1771245032, '7/22/2024'),
(5, 34, 'E567F890G123H456I', 1783456721, '11/13/2024'),
(6, 56, 'A123B456C789D012E', 1794567810, '3/11/2024'),
(7, 34, 'C345D678E901F234G', 1745092031, '5/22/2024'),
(8, 78, 'B234C567D890E123F', 1736709034, '4/30/2024'),
(9, 56, 'E567F890G123H456I', 1753458920, '8/15/2024'),
(10, 12, 'D456E789F012G345H', 1745671230, '10/5/2024'),
(11, 23, 'A123B456C789D012E', 1772345896, '2/14/2024'),
(12, 47, 'C345D678E901F234G', 1793579034, '9/20/2024'),
(13, 58, 'B234C567D890E123F', 1735071893, '7/1/2024'),
(14, 64, 'E567F890G123H456I', 1745692801, '1/15/2024'),
(15, 45, 'D456E789F012G345H', 1758679054, '6/18/2024'),
(16, 23, 'A123B456C789D012E', 1792458390, '11/2/2024'),
(17, 32, 'C345D678E901F234G', 1746790341, '5/6/2024'),
(18, 46, 'B234C567D890E123F', 1759876542, '3/28/2024'),
(19, 78, 'E567F890G123H456I', 1767983452, '8/10/2024'),
(20, 19, 'D456E789F012G345H', 1777654321, '4/24/2024'),
(21, 35, 'A123B456C789D012E', 1786543120, '9/8/2024'),
(22, 51, 'C345D678E901F234G', 1798765432, '1/19/2024'),
(23, 72, 'B234C567D890E123F', 1738904567, '2/22/2024'),
(24, 69, 'E567F890G123H456I', 1749876523, '7/17/2024'),
(25, 43, 'D456E789F012G345H', 1752356987, '10/3/2024'),
(26, 59, 'A123B456C789D012E', 1769034261, '6/15/2024'),
(27, 66, 'C345D678E901F234G', 1792345891, '8/12/2024'),
(28, 79, 'B234C567D890E123F', 1745789023, '11/1/2024'),
(29, 32, 'E567F890G123H456I', 1759236014, '4/7/2024'),
(30, 12, 'D456E789F012G345H', 1778654320, '12/14/2024'),
(31, 25, 'A123B456C789D012E', 1793456890, '2/23/2024'),
(32, 45, 'C345D678E901F234G', 1739087652, '5/29/2024'),
(33, 56, 'B234C567D890E123F', 1752346710, '10/28/2024'),
(34, 62, 'E567F890G123H456I', 1771238905, '7/13/2024'),
(35, 23, 'D456E789F012G345H', 1745092031, '9/16/2024'),
(36, 65, 'A123B456C789D012E', 1794576120, '2/6/2024'),
(37, 16, 'C345D678E901F234G', 1739078641, '5/2/2024'),
(38, 29, 'B234C567D890E123F', 1772458034, '4/21/2024'),
(39, 75, 'E567F890G123H456I', 1764539124, '8/3/2024'),
(40, 44, 'D456E789F012G345H', 1792458361, '12/6/2024'),
(41, 53, 'A123B456C789D012E', 1756712398, '10/20/2024'),
(42, 19, 'C345D678E901F234G', 1786457902, '3/19/2024'),
(43, 82, 'B234C567D890E123F', 1773245680, '7/30/2024'),
(44, 70, 'E567F890G123H456I', 1743025681, '5/22/2024'),
(45, 62, 'D456E789F012G345H', 1734571230, '2/28/2024'),
(46, 26, 'A123B456C789D012E', 1757452316, '9/4/2024'),
(47, 44, 'C345D678E901F234G', 1779082340, '12/2/2024'),
(48, 35, 'B234C567D890E123F', 1762457896, '6/10/2024'),
(49, 68, 'E567F890G123H456I', 1741098762, '4/16/2024'),
(50, 76, 'D456E789F012G345H', 1791245092, '11/30/2024'),
(51, 63, 'A123B456C789D012E', 1734678503, '5/19/2024'),
(52, 14, 'C345D678E901F234G', 1792598471, '7/11/2024'),
(53, 42, 'B234C567D890E123F', 1745032649, '6/2/2024'),
(54, 55, 'E567F890G123H456I', 1762348910, '10/8/2024'),
(55, 21, 'D456E789F012G345H', 1739221107, '1/22/2024'),
(56, 93, 'A123B456C789D012E', 1748965813, '9/1/2024'),
(57, 72, 'C345D678E901F234G', 1779072345, '4/4/2024'),
(58, 61, 'B234C567D890E123F', 1793257420, '5/24/2024'),
(59, 55, 'E567F890G123H456I', 1738924569, '6/17/2024'),
(60, 13, 'D456E789F012G345H', 1749013245, '7/5/2024'),
(61, 81, 'A123B456C789D012E', 1796543721, '3/17/2024'),
(62, 90, 'C345D678E901F234G', 1772345567, '8/9/2024'),
(63, 45, 'B234C567D890E123F', 1738934567, '12/13/2024'),
(64, 36, 'E567F890G123H456I', 1752349876, '2/3/2024'),
(65, 32, 'D456E789F012G345H', 1790675201, '10/15/2024'),
(66, 47, 'A123B456C789D012E', 1745689023, '6/22/2024'),
(67, 74, 'C345D678E901F234G', 1739854312, '1/11/2024'),
(68, 23, 'B234C567D890E123F', 1756790324, '5/12/2024'),
(69, 38, 'E567F890G123H456I', 1794578123, '11/25/2024'),
(70, 56, 'D456E789F012G345H', 1773465679, '8/18/2024'),
(71, 64, 'A123B456C789D012E', 1738569023, '4/1/2024'),
(72, 21, 'C345D678E901F234G', 1759036742, '2/10/2024'),
(73, 31, 'B234C567D890E123F', 1791034123, '3/26/2024'),
(74, 48, 'E567F890G123H456I', 1765098375, '10/21/2024'),
(75, 54, 'D456E789F012G345H', 1796754201, '7/27/2024'),
(76, 66, 'A123B456C789D012E', 1792145876, '11/18/2024'),
(77, 47, 'C345D678E901F234G', 1759843122, '9/2/2024'),
(78, 35, 'B234C567D890E123F', 1745018762, '3/30/2024'),
(79, 59, 'E567F890G123H456I', 1735798322, '7/14/2024'),
(80, 12, 'D456E789F012G345H', 1794561123, '8/27/2024'),
(81, 38, 'A123B456C789D012E', 1749083741, '1/25/2024'),
(82, 67, 'C345D678E901F234G', 1767382341, '5/23/2024'),
(83, 53, 'B234C567D890E123F', 1792357840, '2/13/2024'),
(84, 44, 'E567F890G123H456I', 1758432761, '10/4/2024'),
(85, 77, 'D456E789F012G345H', 1734567891, '9/21/2024'),
(86, 29, 'A123B456C789D012E', 1773245680, '7/5/2024'),
(87, 62, 'C345D678E901F234G', 1752458923, '4/2/2024'),
(88, 46, 'B234C567D890E123F', 1795623098, '3/14/2024'),
(89, 75, 'E567F890G123H456I', 1746578202, '6/23/2024'),
(90, 23, 'D456E789F012G345H', 1738904567, '5/10/2024'),
(91, 64, 'A123B456C789D012E', 1773548901, '8/1/2024'),
(92, 25, 'C345D678E901F234G', 1748976543, '12/3/2024'),
(93, 77, 'B234C567D890E123F', 1795631202, '9/25/2024'),
(94, 43, 'E567F890G123H456I', 1769028435, '3/9/2024'),
(95, 61, 'D456E789F012G345H', 1735067892, '10/18/2024'),
(96, 58, 'A123B456C789D012E', 1772385649, '2/11/2024'),
(97, 35, 'C345D678E901F234G', 1740983452, '5/18/2024'),
(98, 72, 'B234C567D890E123F', 1792348569, '8/29/2024'),
(99, 64, 'E567F890G123H456I', 1779083215, '1/18/2024'),
(100, 54, 'D456E789F012G345H', 1756748920, '4/27/2024');

